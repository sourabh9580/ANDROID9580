package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    Button button0,button1,button2,button3,button4,button5,button6,button7,button8,button9,buttondot,buttonadd,buttonsub,buttonmul,buttonequal,buttondiv,buttonclear;
    EditText ed1;

    Float mValueOne,mValueTwo,res;
    Boolean aBooleanadd,aBooleansub,aBooleanmul,aBooleandiv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button0=(Button)findViewById(R.id.button0);
        button1=(Button)findViewById(R.id.button1);
        button2=(Button)findViewById(R.id.button2);
        button3=(Button)findViewById(R.id.button3);
        button4=(Button)findViewById(R.id.button4);
        button5=(Button)findViewById(R.id.button5);
        button6=(Button)findViewById(R.id.button6);
        button7=(Button)findViewById(R.id.button7);
        button8=(Button)findViewById(R.id.button8);
        button9=(Button)findViewById(R.id.button9);
        buttondot=(Button)findViewById(R.id.buttondot);
        buttonadd=(Button)findViewById(R.id.buttonadd);
        buttonsub=(Button)findViewById(R.id.buttonsub);
        buttonmul=(Button)findViewById(R.id.buttonmul);
        buttondiv=(Button)findViewById(R.id.buttondiv);
        buttonequal=(Button)findViewById(R.id.buttonequal);
        buttonclear=(Button)findViewById(R.id.buttonclear);
        ed1=(EditText)findViewById(R.id.editText);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ed1.setText(ed1.getText()+"1");
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ed1.setText(ed1.getText()+"2");
            }
        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ed1.setText(ed1.getText()+"3");
            }
        });
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ed1.setText(ed1.getText()+"4");
            }
        });
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ed1.setText(ed1.getText()+"5");
            }
        });
        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ed1.setText(ed1.getText()+"6");
            }
        });
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ed1.setText(ed1.getText()+"7");
            }
        });
        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ed1.setText(ed1.getText()+"8");
            }
        });
        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ed1.setText(ed1.getText()+"9");
            }
        });
        button0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ed1.setText(ed1.getText()+"0");
            }
        });
        buttonadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ed1==null){
                    ed1.setText("");
                }else {
                    mValueOne = Float.parseFloat(ed1.getText()+"");
                    aBooleanadd=true;
                    ed1.setText(null);
                }
            }
        });
        buttonsub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    mValueOne = Float.parseFloat(ed1.getText()+"");
                    aBooleansub=true;
                    ed1.setText(null);

            }
        });
        buttonmul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 mValueOne = Float.parseFloat(ed1.getText()+"");
                    aBooleanmul=true;
                    ed1.setText(null);

            }
        });

        buttondiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 mValueOne = Float.parseFloat(ed1.getText()+"");
                    aBooleandiv=true;
                    ed1.setText(null);

            }
        });
        buttonequal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mValueTwo=Float.parseFloat(ed1.getText()+"");

                if(aBooleanadd == true){
                    res=mValueOne + mValueTwo;
                    ed1.setText(mValueOne + mValueTwo +"");
                    //ed1.setText(res);
                    aBooleanadd=false;
                }
                else if(aBooleansub == true){
                    //res= mValueOne - mValueTwo;
                    ed1.setText(mValueOne - mValueTwo +"");
                    aBooleansub=false;
                }
                else if(aBooleanmul == true){
                    //res= mValueOne * mValueTwo;
                    ed1.setText(mValueOne * mValueTwo +"");
                    aBooleanmul=false;
                }
                else if(aBooleandiv == true){
                    //res= mValueOne / mValueTwo;
                    ed1.setText(mValueOne / mValueTwo +"");
                    aBooleandiv=false;
                }

            }
        });

        buttonclear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ed1.setText("");
            }
        });
        buttondot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ed1.setText(ed1.getText()+".");
            }
        });


    }
}
