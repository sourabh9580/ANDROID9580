package com.example.practiceapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    Button btn, pop;
    AutoCompleteTextView autocompletetext;
    String[] names ={"Vivek", "Manan", "Raj"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setTitle("Menus");
        autocompletetext = findViewById(R.id.autoComplete);
        ArrayAdapter adapter = new ArrayAdapter(this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,names);
        autocompletetext.setAdapter(adapter);
        autocompletetext.setThreshold(1);
        Log.d("lifecycle","onCreate invoked");
        btn=findViewById(R.id.button);
        registerForContextMenu(btn);
        pop=findViewById(R.id.button2);
        pop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                PopupMenu p = new PopupMenu(MainActivity.this,pop);
                p.getMenuInflater().inflate(R.menu.mymenu,p.getMenu());
                p.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        Toast.makeText(MainActivity.this,menuItem.getTitle()+ " Selected",Toast.LENGTH_LONG).show();
                        return true;
                    }
                });
                p.show();
            }
        });


            AlertDialog.Builder alert = new AlertDialog.Builder(this);
            alert.setCancelable(false);
            alert.setMessage("Are you sure you want to continue?");
            alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    Toast.makeText(MainActivity.this,"You chose to continue",Toast.LENGTH_LONG).show();
                }
            });

            alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    finish();
                }
            });
            AlertDialog display = alert.create();
            display.show();

    }




    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.mymenu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){

            case R.id.m1:
                //Toast.makeText(this,item.getTitle()+ " Selected",Toast.LENGTH_LONG).show();
                Intent i = new Intent(MainActivity.this,MainActivity2.class);
                startActivity(i);
                break;

            case R.id.m2:
                //Toast.makeText(this,item.getTitle()+ " Selected",Toast.LENGTH_LONG).show();
                Intent i2 = new Intent(MainActivity.this,sqlite.class);
                startActivity(i2);
                break;

            case R.id.m3:
                Toast.makeText(this,item.getTitle()+ " Selected",Toast.LENGTH_LONG).show();
                break;

        }
        return true;
    }

    public void onCreateContextMenu(ContextMenu contextmenu,View view,ContextMenu.ContextMenuInfo context){
        getMenuInflater().inflate(R.menu.mymenu,contextmenu);
    }

    public boolean onContextItemSelected(MenuItem item){
        switch (item.getItemId()){

            case R.id.m1:
                Toast.makeText(this,item.getTitle()+ " Selected",Toast.LENGTH_LONG).show();
                break;

            case R.id.m2:
                Toast.makeText(this,item.getTitle()+ " Selected",Toast.LENGTH_LONG).show();
                break;

            case R.id.m3:
                Toast.makeText(this,item.getTitle()+ " Selected",Toast.LENGTH_LONG).show();
                break;

        }
        return false;
    }
    @Override
    protected void onStart() {

        super.onStart();
        Log.d("lifecycle","onStart invoked");
    }

    @Override
    protected void onResume() {

        super.onResume();
        Log.d("lifecycle","onResume invoked");
    }

    @Override
    protected void onPause() {

        super.onPause();
        Log.d("lifecycle","onPause invoked");
    }

    @Override
    protected void onRestart() {

        super.onRestart();
        Log.d("lifecycle","onRestart invoked");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("lifecycle","onDestroy invoked");
    }
}