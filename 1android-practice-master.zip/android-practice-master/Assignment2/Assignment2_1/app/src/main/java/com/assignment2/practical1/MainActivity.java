package com.assignment2.practical1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText name, age, address, city, phone;
    Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name=findViewById(R.id.txtName);
        age=findViewById(R.id.numAge);
        address=findViewById(R.id.txtAddress);
        city=findViewById(R.id.txtCity);
        phone=findViewById(R.id.numPhone);
        submit=findViewById(R.id.submitdata);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this,student_info.class);
                i.putExtra("Name",name.getText().toString());
                i.putExtra("Age",age.getText().toString());
                i.putExtra("Address",address.getText().toString());
                i.putExtra("City",city.getText().toString());
                i.putExtra("Phone",phone.getText().toString());
                startActivity(i);
            }
        });
    }
}