package com.assignment2.practical2;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText input;
    ImageView enter;
    ListView listView;
    ArrayList<String> items;
    ArrayAdapter<String> adapter;
    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView =(ListView) findViewById(R.id.listView);
        input = (EditText) findViewById(R.id.input);
        enter = (ImageView) findViewById(R.id.enter);
        items = new ArrayList<>();
        items.add("Initial item");
        adapter = new ArrayAdapter<>(getApplicationContext(),
                android.R.layout.simple_list_item_1, items);
        listView.setAdapter(adapter);

        enter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String text = input.getText().toString();
                if(text == null || text.length() == 0){
                    Toast.makeText(getApplicationContext(),"Enter an Item ",Toast.LENGTH_SHORT).show();
                }else{
                    addItem(text);
                    input.setText("");
                }
            }
        });
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                String name = (String) adapterView.getItemAtPosition(i);
                final int which_item = i;
                new AlertDialog.Builder(MainActivity.this)
                        .setIcon(android.R.drawable.ic_delete)
                        .setTitle("Are you sure?")
                        .setMessage("Do you want to delete this item named : " + name +"?")
                        .setPositiveButton("Yes", new
                                DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                items.remove(which_item);
                                adapter.notifyDataSetChanged();
                                Toast.makeText(getApplicationContext(),"Removed Item named - " + name,Toast.LENGTH_SHORT).show();
                            }
                        })
                        .setNegativeButton("No", null)
                        .show();
                return true;
            }
        });
    }
    public void addItem(String item){
        items.add(item);
        adapter.notifyDataSetChanged();
    }
    public void removeItem(int item){
        items.remove(item);
        adapter.notifyDataSetChanged();
    }
}