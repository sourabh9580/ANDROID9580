package com.assignment2.practical5;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;

import com.android.car.ui.AlertDialogBuilder;

import java.util.List;

public class CustomAdapter extends ArrayAdapter<String> {

    private Context context;
    private TextView listitem;
    private ImageView editbtn;
    private ImageView deletebtn;
    private List<String> listvalues;

    public CustomAdapter(@NonNull Context context, int resource, @NonNull List<String> listvalues) {
        super(context, resource, listvalues);
        this.context = context;
        this.listvalues = listvalues;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        String currentvalue = listvalues.get(position);

        LayoutInflater inflater = LayoutInflater.from(context);

        convertView = inflater.inflate(R.layout.row_item,null);

        listitem = convertView.findViewById(R.id.item);
        listitem.setText(currentvalue);

        listitem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                employeedb data = new employeedb(context,"Employee",null,1);
                Cursor getdata = data.getAlldata(listvalues.get(position));
                Intent i = new Intent(context, employeedata.class);
                while(getdata.moveToNext()){
                    i.putExtra(getdata.getColumnName(0),getdata.getString(0));
                    i.putExtra(getdata.getColumnName(1),getdata.getString(1));
                    i.putExtra(getdata.getColumnName(2),getdata.getString(2));
                    i.putExtra(getdata.getColumnName(3),getdata.getString(3));
                    i.putExtra(getdata.getColumnName(4),getdata.getString(4));
                }
                context.startActivity(i);
                //Log.i("TAG",data.getNames().toString());
                /*Intent i = new Intent(context, employeedata.class);
                i.putExtra("ID",getdata.getString(0));
                i.putExtra("Name",getdata.getString(1));
                i.putExtra("Designation",getdata.getString(2));
                i.putExtra("City",getdata.getString(3));
                i.putExtra("DOJ",getdata.getString(4));
                context.startActivity(i);*/
            }
        });



        editbtn = convertView.findViewById(R.id.edit);

        editbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                employeedb data = new employeedb(context,"Employee",null,1);
                Cursor getdata = data.getAlldata(listvalues.get(position));
                Intent i = new Intent(context, editemployee.class);
                while(getdata.moveToNext()){
                    i.putExtra(getdata.getColumnName(0),getdata.getString(0));
                    i.putExtra(getdata.getColumnName(1),getdata.getString(1));
                    i.putExtra(getdata.getColumnName(2),getdata.getString(2));
                    i.putExtra(getdata.getColumnName(3),getdata.getString(3));
                    i.putExtra(getdata.getColumnName(4),getdata.getString(4));
                }
                context.startActivity(i);
            }
        });

        deletebtn = convertView.findViewById(R.id.delete);

        deletebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder alert = new AlertDialog.Builder(context);
                alert.setCancelable(false);
                alert.setMessage("Are you sure you want to delete data?");
                alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        employeedb db = new employeedb(context,"Employee",null,1);
                        db.deleteData(listvalues.get(position));
                        clear();
                        addAll(db.getNames());
                        notifyDataSetChanged();
                    }
                });

                alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                });
                AlertDialog display = alert.create();
                display.show();
            }
        });

        return convertView;
    }
}
