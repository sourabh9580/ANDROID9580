package com.assignment2.practical5;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class employeedb extends SQLiteOpenHelper {
    public employeedb(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, "Employee", factory, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create table emp (eid integer primary key autoincrement,name text,designation text,city text, doj text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("drop table if exists emp");
        onCreate(sqLiteDatabase);
    }

    public void addData(String name, String designation, String city, String doj){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name",name);
        cv.put("designation",designation);
        cv.put("city",city);
        cv.put("doj",doj);
        db.insert("emp",null,cv);
        db.close();
    }

    public void updateData(String id, String name, String designation, String city, String doj){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name",name);
        cv.put("designation",designation);
        cv.put("city",city);
        cv.put("doj",doj);
        db.update("emp",cv,"eid=?",new String[]{id});
        db.close();
    }

    public void deleteData(String name){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("emp","name=?",new String[]{name});
        db.close();
    }

    public List<String> getNames(){
        List<String> namelist = new ArrayList<>();
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select name from emp",null);

        while(res.moveToNext()){
            namelist.add(res.getString(0));
        }
        return namelist;
    }

    public Cursor getAlldata(String name){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data = db.rawQuery("select * from emp where name=?",new String[]{name});
        return data;
    }
}
