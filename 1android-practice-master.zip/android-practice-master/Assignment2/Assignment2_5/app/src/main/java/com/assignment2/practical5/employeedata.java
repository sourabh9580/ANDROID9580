package com.assignment2.practical5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class employeedata extends AppCompatActivity {

    TextView id, name, designation, city, doj;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employeedata);
        id=findViewById(R.id.txtid);
        name=findViewById(R.id.txtname);
        designation=findViewById(R.id.txtdesignation);
        city=findViewById(R.id.txtcity);
        doj=findViewById(R.id.txtdoj);

        Intent i = getIntent();
        id.setText(i.getStringExtra("eid"));
        name.setText(i.getStringExtra("name"));
        designation.setText(i.getStringExtra("designation"));
        city.setText(i.getStringExtra("city"));
        doj.setText(i.getStringExtra("doj"));
    }
}