package com.assignment2.practical5;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class editemployee extends AppCompatActivity {

    TextView id;
    EditText name,designation,city,doj;
    ImageView calender;
    Button editbtn;
    private DatePicker datePicker;
    private Calendar cal;
    private int year,month,day;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editemployee);
        Intent i = getIntent();
        id=findViewById(R.id.txtid);
        id.setText(i.getStringExtra("eid"));

        name=findViewById(R.id.txtname);
        name.setText(i.getStringExtra("name"));

        designation=findViewById(R.id.txtdesignation);
        designation.setText(i.getStringExtra("designation"));

        city=findViewById(R.id.txtcity);
        city.setText(i.getStringExtra("city"));

        doj=findViewById(R.id.txtdoj);
        doj.setText(i.getStringExtra("doj"));


        calender=findViewById(R.id.calender);
        cal=Calendar.getInstance();
        year=cal.get(Calendar.YEAR);
        month=cal.get(Calendar.MONTH);
        day=cal.get(Calendar.DAY_OF_MONTH);
        calender.setOnClickListener(new View.OnClickListener() {
            @SuppressWarnings("deprecation")
            @Override
            public void onClick(View view) {
                showDialog(999);
                Toast.makeText(getApplicationContext(),"calender",Toast.LENGTH_SHORT).show();
            }
        });


        editbtn=findViewById(R.id.updatedata);
        editbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                employeedb db = new employeedb(editemployee.this,"Employee",null,1);
                db.updateData(id.getText().toString(),name.getText().toString(),designation.getText().toString(),city.getText().toString(),doj.getText().toString());
                Intent i = new Intent(editemployee.this,MainActivity.class);
                startActivity(i);
            }
        });




    }
    @SuppressWarnings("deprecation")
    @Override
    protected Dialog onCreateDialog(int id){

        if(id == 999){
            return new DatePickerDialog(this,mydatelistener,year,month,day);
        }
        return null;
    }

    private DatePickerDialog.OnDateSetListener mydatelistener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
            showDate(i,i1+1,i2);
        }
    };

    private void showDate(int year,int month, int day){
        doj.setText(new StringBuffer().append(day).append("/").append(month).append("/").append(year));
    }
}