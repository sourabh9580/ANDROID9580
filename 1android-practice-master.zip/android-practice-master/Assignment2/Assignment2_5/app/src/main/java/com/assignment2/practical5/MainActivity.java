package com.assignment2.practical5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ListView employeelist;
    private CustomAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        employeedb employee = new employeedb(this,"Employee",null,1);
        List<String> items = employee.getNames();

        employeelist=findViewById(R.id.employeelist);

        adapter = new CustomAdapter(MainActivity.this,R.layout.row_item,items);
        employeelist.setAdapter(adapter);

    }

    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.mymenu,menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){

            case R.id.add:
                Intent i = new Intent(MainActivity.this,addemployee.class);
                startActivity(i);
                break;
        }
        return true;
    }
}