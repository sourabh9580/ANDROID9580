package com.example.a02;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ArrayAdapter<String> adapter;
    String[] Car = new String[] {

    };
    ListView list;
    Button addBtn, removeBtn;
    EditText et;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        list = findViewById(R.id.listView);
        addBtn = findViewById(R.id.btnadd);
        removeBtn = findViewById(R.id.btnremove);
        et = findViewById(R.id.textbox);

        List<String> car_list = new ArrayList<String>(Arrays.asList(Car));

        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, car_list);

        list.setAdapter(adapter);

        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                car_list.add(et.getText().toString());
                adapter.notifyDataSetChanged();
            }
        });

        removeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                car_list.remove(et.getText().toString());
                adapter.notifyDataSetChanged();            }
        });




    }
}