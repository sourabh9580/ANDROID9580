package com.assignment2.practical4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class BComLLB extends AppCompatActivity {

    TextView description;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bcom_llb);
        getSupportActionBar().setTitle("Bcom LLB");
        description=findViewById(R.id.bcom_desc);
        description.setText("To evolve as a center of excellence in areas\n" +
                "of teaching, learning, research, extension and community\n" +
                "service. To equip the students to compete nationally and\n" +
                "globally in areas of legal profession, justicing and to meet the\n" +
                "challenges of the globalized world.\n" +
                "To strengthen traditions of knowledge and scholarship");
    }
}