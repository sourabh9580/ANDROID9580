package com.example.assignment5;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {
    public static final String TAG= MainActivity.class.getCanonicalName();
    db_helper obj=new db_helper(this,null,null,1);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //obj.adddata();
        //obj.update_rec();
        String stren;
        Cursor result= obj.read_data();
        while (result.moveToNext()){
            stren=result.getString( result.getColumnIndex("name"));
            Log.i(TAG,"name="+stren);
        }
    }
}