package com.example.assignment5;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class db_helper extends SQLiteOpenHelper {

    public db_helper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, "employee", factory, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create table emp(eid integer primary key AUTOINCREMENT, Name vtext, dob text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("drop table if exists emp");
        onCreate(sqLiteDatabase);

    }
    public void adddata(){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();

        cv.put("Name","sourabh");
        cv.put("dob", "nov");
        db.insert("emp",null,cv);
        db.close();
    }
    public void update_rec(){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("dob","mon");
        db.update("emp",cv,"eid=?",new String[]{Integer.toString(1)});
        db.close();
    }
    public Cursor read_data(){
        Cursor res;
        SQLiteDatabase db=this.getReadableDatabase();
        res=db.rawQuery("select * from emp",null);
        return res;
    }
}

