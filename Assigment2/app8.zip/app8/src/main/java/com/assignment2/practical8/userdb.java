package com.assignment2.practical8;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class userdb extends SQLiteOpenHelper {

    private Context context;
    public userdb(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, "User", factory, 1);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create table users (username text primary key,name text,email text,password text)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("drop table if exists users");
        onCreate(sqLiteDatabase);

    }

    public static final String md5(final String s){

        final String MD5 = "MD5";

        try {
            MessageDigest digest = MessageDigest.getInstance(MD5);
            digest.update(s.getBytes());
            byte[] messageDigest = digest.digest();

            StringBuilder hexstring = new StringBuilder();

            for(byte amessagedigest : messageDigest){
                String h = Integer.toHexString(0xFF & amessagedigest);
                while(h.length() < 2){
                    h = 0 + h;
                    hexstring.append(h);
                }
            }
            return  hexstring.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return "";
    }

    public void insert(String username, String name, String email, String password){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor result = db.rawQuery("select * from users where username=?",new String[]{username});

        if(result.getCount() > 0){
            Toast.makeText(context,"Username already exists",Toast.LENGTH_SHORT).show();
        }else{
            password = md5(password);
            ContentValues cv = new ContentValues();
            cv.put("username",username);
            cv.put("name",name);
            cv.put("email",email);
            cv.put("password",password);
            db.insert("users",null,cv);
            db.close();
            Toast.makeText(context,"Registration successful",Toast.LENGTH_SHORT).show();
        }
    }
}
