package com.assignment2.practical8;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText username, name, email, password;
    Button register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        username=findViewById(R.id.txtusername);
        name=findViewById(R.id.txtname);
        email=findViewById(R.id.txtemail);
        password=findViewById(R.id.txtpassword);
        register=findViewById(R.id.register);


        userdb data = new userdb(MainActivity.this,"User",null,1);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data.insert(username.getText().toString(),name.getText().toString()
                        ,email.getText().toString(),password.getText().toString());
                username.setText(null);
                name.setText(null);
                email.setText(null);
                password.setText(null);
            }
        });


    }
}