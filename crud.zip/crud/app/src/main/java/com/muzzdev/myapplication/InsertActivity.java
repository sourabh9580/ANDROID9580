package com.muzzdev.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class InsertActivity extends AppCompatActivity {
    AutoCompleteTextView Designation;
    Button insert;
    EditText Name,Phone,Email;
    DBHelper DB = new DBHelper(this,null,null,1);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert);


        String[] arr = { "manager", "executive", "clerk", "chief executive","senior-clerk"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.select_dialog_item, arr);
        Designation.setThreshold(2);
        Designation.setAdapter(adapter);


        insert=findViewById(R.id.btninsert);
        Name=findViewById(R.id.edempname);
        Designation= findViewById(R.id.autoCompleteTextView);
        Phone=findViewById(R.id.edphone);
        Email=findViewById(R.id.edemail);

        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String txtname=Name.getText().toString();
                String txtdesig= Designation.getText().toString();
                String txtphone=Phone.getText().toString();
                String txtemail=Email.getText().toString();

                Boolean checkinsertdata = DB.insertempdata(txtname,txtdesig,txtphone,txtemail);
                if(checkinsertdata == true){
                    Toast.makeText(InsertActivity.this, "Insert Data Successfully", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(InsertActivity.this, "Insert data not successfully", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}