package com.muzzdev.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ListView crudlist;
        ArrayList<String> crud;
        ArrayAdapter<String> adapter;
        getSupportActionBar().setTitle("Crud");

        crudlist =findViewById(R.id.lv);
        crud = new ArrayList<>();
        crud.add("Insert");
        crud.add("View Data");
        crud.add("Search");
        adapter=new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1,crud);
        crudlist.setAdapter(adapter);
        crudlist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if(i==0){
                    startActivity(new Intent(MainActivity.this,InsertActivity.class));
                }else if(i==1){
                    startActivity(new Intent(MainActivity.this,ViewActivity.class));
                }else if(i==2){
                    startActivity(new Intent(MainActivity.this,SearchActivity.class));
                }

            }
        });
    }
}
