package com.muzzdev.myapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class ViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);
        Button view;
        DBHelper db = new DBHelper(this,null,null,1);
        view=findViewById(R.id.btnview);

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor res = db.viewdata();
                if(res.getCount()==0){
                    Toast.makeText(ViewActivity.this, "No Entry Exist", Toast.LENGTH_SHORT).show();
                }
                StringBuffer buffer= new StringBuffer();
                AlertDialog.Builder builder=new AlertDialog.Builder(ViewActivity.this);
                while (res.moveToNext()){
                    buffer.append("ID: "+res.getString(0)+"\n");
                    buffer.append("Name: "+res.getString(1)+"\n");
                    buffer.append("Designation: "+res.getString(2)+"\n");
                    buffer.append("Phone: "+res.getString(3)+"\n");
                    buffer.append("Email: "+res.getString(4)+"\n");
                    buffer.append("\n");
                }
                builder.setCancelable(true);
                builder.setTitle("Employee Deatil");
                builder.setMessage(buffer.toString());
                builder.show();
            }
        });
    }
}