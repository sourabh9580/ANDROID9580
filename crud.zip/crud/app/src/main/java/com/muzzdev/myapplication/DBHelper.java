package com.muzzdev.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {
    public DBHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, "empdata", null , 1);
    }

    @Override
    public void onCreate(SQLiteDatabase DB) {
        DB.execSQL("create Table if not exists empdata(empid integer primary key AutoIncrement,empname Text,emp_designation text,emp_phone integer,emp_email Text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase DB, int i, int i1) {
        onCreate(DB);
    }

    public boolean insertempdata(String empname,String emp_Designation,String emp_phone,String emp_email){
        SQLiteDatabase DB=this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("empname",empname);
        cv.put("emp_Designation",emp_Designation);
        cv.put("emp_phone",emp_phone);
        cv.put("emp_email",emp_email);
        long result=DB.insert("empdata",null,cv);
        if (result==-1){
            return false;
        }
        return true;

    }

    public Cursor viewdata(){
        SQLiteDatabase DB= this.getWritableDatabase();
        Cursor cursor=DB.rawQuery("select * from empdata",null);
        return cursor;
    }
    public Cursor searchdata(String empname){
        SQLiteDatabase DB=this.getWritableDatabase();
        Cursor cursor= DB.rawQuery("select * from empdata where empname=?",new String[]{empname});
        return cursor;
    }
}



